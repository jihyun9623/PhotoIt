-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: photoit
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `my_studio`
--

DROP TABLE IF EXISTS `my_studio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `my_studio` (
  `studio_idx` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `profile` varchar(255) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`studio_idx`),
  UNIQUE KEY `UK_is3tbs7y5iwj60wdwotgcco69` (`nickname`),
  KEY `FK9a8s88qkov0ql7xq4649bgfts` (`user_id`),
  CONSTRAINT `FK9a8s88qkov0ql7xq4649bgfts` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_studio`
--

LOCK TABLES `my_studio` WRITE;
/*!40000 ALTER TABLE `my_studio` DISABLE KEYS */;
INSERT INTO `my_studio` VALUES (16,'세령작가','무말랭이 작가입니다',30),(17,'한뀨','뀨뀨뀨뀨',31),(19,'qwe','한낱 사진쟁이입니다.',32),(20,'한규대장','한규대장! 드디어 사진나라에 돌아온거야?',34),(23,'테스트용','',36),(24,'test_sj',NULL,37),(25,'test_sj2',NULL,38),(27,'한규킹','갓한규 짱한규',40),(28,'한작가','한 장의 사진이라도',45),(30,'김작가','사진쟁이 김씨입니다 :)',47),(32,'이작가','찰칵찰칵 이작가',52),(33,'mystudio_test','마이스튜디오 테스트용 계정입니다.',58),(34,'영상테스트','안녕하세요 영상테스트 진행합니다',63),(35,'팟칭','팟칭-!',65),(36,'영상최종테스트','영상테스트 진행합니다.',66);
/*!40000 ALTER TABLE `my_studio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  3:25:32
