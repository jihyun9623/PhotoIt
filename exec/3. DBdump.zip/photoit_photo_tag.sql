-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: photoit
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `photo_tag`
--

DROP TABLE IF EXISTS `photo_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photo_tag` (
  `phototag_idx` int NOT NULL AUTO_INCREMENT,
  `photo_idx` int DEFAULT NULL,
  `tag_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`phototag_idx`),
  KEY `FKkn2mtxj50v8c0oej1vw4vp1v1` (`tag_name`),
  KEY `FK34x4c9rms34symm9tmymguf9v` (`photo_idx`),
  CONSTRAINT `FK34x4c9rms34symm9tmymguf9v` FOREIGN KEY (`photo_idx`) REFERENCES `photo` (`photo_idx`) ON DELETE CASCADE,
  CONSTRAINT `FKkn2mtxj50v8c0oej1vw4vp1v1` FOREIGN KEY (`tag_name`) REFERENCES `tag` (`tag_name`)
) ENGINE=InnoDB AUTO_INCREMENT=438 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo_tag`
--

LOCK TABLES `photo_tag` WRITE;
/*!40000 ALTER TABLE `photo_tag` DISABLE KEYS */;
INSERT INTO `photo_tag` VALUES (281,2,'가족'),(282,3,'가족'),(283,4,'가족'),(284,5,'가족'),(285,6,'가족'),(286,7,'가족'),(287,8,'가족'),(291,12,'동물'),(292,13,'동물'),(293,14,'동물'),(294,15,'동물'),(295,16,'동물'),(296,17,'동물'),(297,18,'동물'),(298,19,'동물'),(299,20,'동물'),(300,21,'동물'),(301,22,'바다'),(302,23,'바다'),(303,24,'바다'),(304,25,'바다'),(305,26,'바다'),(306,27,'바다'),(307,28,'바다'),(308,29,'바다'),(309,30,'바다'),(310,31,'바다'),(311,32,'바디프로필'),(312,33,'한복'),(313,34,'커플'),(314,35,'여행'),(315,36,'커플'),(316,37,'커플'),(317,38,'웨딩'),(318,39,'동물'),(319,40,'웨딩'),(320,41,'요리'),(321,42,'한복'),(322,43,'한복'),(323,44,'우정'),(324,45,'커플'),(325,46,'커플'),(326,47,'바다'),(327,48,'점프'),(328,49,'커플'),(329,50,'웨딩'),(330,51,'졸업'),(331,52,'우정'),(332,53,'커플'),(333,54,'여행'),(334,55,'웨딩'),(335,56,'요리'),(336,57,'점프'),(337,58,'점프'),(338,59,'우정'),(339,60,'여행'),(340,61,'요리'),(341,62,'웨딩'),(342,63,'웨딩'),(343,64,'야외'),(344,65,'웨딩'),(345,66,'요리'),(346,67,'프로필'),(347,68,'프로필'),(348,69,'프로필'),(349,70,'우정'),(350,71,'졸업'),(351,72,'졸업'),(352,73,'졸업'),(353,74,'졸업'),(354,75,'졸업'),(355,76,'졸업'),(356,77,'프로필'),(357,78,'커플'),(358,79,'점프'),(359,80,'야외'),(360,81,'요리'),(361,82,'웨딩'),(362,83,'야외'),(363,84,'웨딩'),(364,85,'요리'),(365,86,'요리'),(366,87,'야외'),(367,88,'아기'),(368,89,'요리'),(369,90,'우정'),(370,91,'커플'),(371,92,'프로필'),(372,93,'점프'),(373,94,'점프'),(374,95,'웨딩'),(375,96,'프로필'),(376,97,'프로필'),(377,98,'프로필'),(378,99,'아기'),(379,100,'아기'),(380,101,'아기'),(381,102,'아기'),(382,103,'아기'),(383,104,'아기'),(384,105,'아기'),(385,106,'아기'),(386,107,'아기'),(387,108,'수중'),(388,109,'수중'),(389,110,'수중'),(390,111,'수중'),(391,112,'수중'),(392,113,'수중'),(393,114,'수중'),(394,115,'수중'),(395,116,'수중'),(396,117,'수중'),(397,118,'수중'),(398,119,'우정'),(399,120,'요리'),(400,121,'한복'),(401,122,'점프'),(402,123,'바디프로필'),(403,124,'요리'),(404,125,'웨딩'),(405,126,'바디프로필'),(406,127,'바디프로필'),(407,128,'바디프로필'),(408,129,'야외'),(409,130,'우정'),(410,131,'우정'),(411,132,'요리'),(412,133,'점프'),(413,134,'우정'),(414,135,'웨딩'),(415,136,'웨딩'),(416,137,'점프'),(417,138,'커플'),(418,139,'커플'),(419,140,'웨딩'),(420,141,'졸업');
/*!40000 ALTER TABLE `photo_tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  3:25:35
