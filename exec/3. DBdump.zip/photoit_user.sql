-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: photoit
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_idx` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `pg` tinyint(1) NOT NULL DEFAULT '0',
  `photo` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_idx`),
  UNIQUE KEY `UK_a3imlf41l37utmxiquukk8ajc` (`user_id`),
  UNIQUE KEY `UK_n4swgcf30j6bmtb4l4cjryuym` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (30,'psr@naver.com','세령작가','{bcrypt}$2a$10$Wwl9yX8PvGlPLiWbC0Vgcuq5wrciAXbTB9FA0Un.DR1IQLfVNa8v6',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/penguinuhh-PuXtB1B4zL8-unsplash.jpg','PG'),(31,'hanq@naver.com','한뀨','{bcrypt}$2a$10$DqFXJ/dq9ZWkL2VflCxBZORH5NGNQgOzNp36Ojl53zSWFnEqRPm86',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/photo-it_2021-08-05_bfe1c1d8-f6d5-45db-b7f1-958147eae923.jpg','PG'),(32,'qwe@qwe.com','qwe','{bcrypt}$2a$10$kdE/xgmrKugE6haJyYh4DOTdzRidLWfiKwHL3N2l11Max.83NentK',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/KakaoTalk_20210805_221006698_02.jpg','PG'),(34,'HanQ@gmail.com','한규대장','{bcrypt}$2a$10$2YkKjY8FJNkGG.fqADhaXOHgUoA3699O7mPqZgoOtFyDE8GIq/u/q',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/man-1867887_1920.jpg','PG'),(36,'test_sj@naver.com','테스트용','{bcrypt}$2a$10$cn1/O.G3KUeLUXiYL1VTBeDTgVBhWrhy/.DjojcG2l6gor2tmWP/6',1,NULL,'PG'),(37,'test_sj1@naver.com','test_sj','{bcrypt}$2a$10$LQiQ3ihsQ8scqJomgbdwfOElVYsPgLAGWYTZ39SiDVQHFQi0PWPEq',1,NULL,'PG'),(38,'test_sj2@naver.com','test_sj2','{bcrypt}$2a$10$/pIEU3rQ1ZSCCIvxForD/.N4lyRYQ.FKF4QSxeJ4z43IVHihsKGhy',1,NULL,'PG'),(40,'kingHanq@naver.com','한규킹','{bcrypt}$2a$10$FiF9qHr8bYbCJv6hGPFdDejwYOqKUDX58iK31iG07DGYMnFlc1gQS',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/KakaoTalk_20210805_221107976_05.jpg','PG'),(45,'pghan@naver.com','한작가','{bcrypt}$2a$10$2Z9dJQ8O8jEeUXESGAOLIOjBOgfBcm4V75gvjIXkGel609SuisCBy',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/candice-picard-vLENm-coX5Y-unsplash.jpg','PG'),(47,'pgkim@naver.com','김작가','{bcrypt}$2a$10$b.Jn56LSHJ2Fl7d4Hufdg.PWBeS89H8WO9Gyi6e0TPpnZHb02c8F6',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/jason-briscoe-GrdJp16CPk8-unsplash.jpg','PG'),(52,'pglee@naver.com','이작가','{bcrypt}$2a$10$2nDnXwK/JspoQ1XVUVmfiuuy3037prtos.O1Ky5hOcIZ7rzqW0D9S',1,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/naassom-azevedo-Q_Sei-TqSlc-unsplash.jpg','PG'),(53,'hanq_s@god.c','godhanq','{bcrypt}$2a$10$KwTtpn.vHmFif1CdQHzP7OhwZ3n/a8aGP1BZeJ8KRzSc.hv1EtWcC',0,NULL,'USER'),(54,'qwer1234@qwer.com','qwer1234','{bcrypt}$2a$10$63X1Avohzo0IvHvx1TwVZ.0ExQpjVI9/7EO5bfDz5aKkTymvG6D1q',0,NULL,'USER'),(55,'signup_final_test@test.com','final_test','{bcrypt}$2a$10$J6yT613adMeSmDsoZJ.gLOkSK0ghtmk4RYoANJOaukDpI8604GWSy',0,NULL,'USER'),(56,'signup_final_final_test@test.com','final_final_test','{bcrypt}$2a$10$Bc69sn16b08U0juCPqwX3OsBsc4CdWokpceO/baPeSFI4nBDZjpF6',0,NULL,'USER'),(57,'signup_final_test2@test.com','final_real_test','{bcrypt}$2a$10$qRRN2i1CBB5SDrmfmGrcuOM89lS6azV.snafi0kWw6jWGVfH8uXw.',0,NULL,'USER'),(58,'mystudio_test@test.com','mystudio_test','{bcrypt}$2a$10$UIYRs/rYncQko47wKhyA2eB1AmzMHe3VWfqmd29KlYg7fRrfPlQrK',1,NULL,'PG'),(59,'asd@asd.com','은총님테스트계정','{bcrypt}$2a$10$ZG.I1XVJLe9OEdIPnu6H.O.K27fYm7oB4CsfI6396vfL9sEm.2PhK',0,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/photo-it_2021-08-05_bfe1c1d8-f6d5-45db-b7f1-958147eae923.jpg','USER'),(60,'user@naver.com','일반회원','{bcrypt}$2a$10$0lI6adaCAZ5y/PgmDam6Ne.y/shgDtWnUAnGGpDKv0WL4y5LRyAbO',0,'https://a108-photo-it.s3.ap-northeast-2.amazonaws.com/origin/helena-lopes-PGnqT0rXWLs-unsplash.jpg','USER'),(61,'deleteuser@naver.com','마이페이지디버깅용입니다','{bcrypt}$2a$10$4/IkshNTvhce08DnzMtBJe/zMNW8cQOsYjkt854ux6nLw0CHxYjL6',0,'string','USER'),(62,'hanq@kakao.com','hanq','{bcrypt}$2a$10$FAadpR98PNAA5ERpz1YMZ.i9rtjtP6TUR9cFQlZYixNHjbN8jjD/q',0,NULL,'USER'),(63,'sangjea5@naver.com','영상테스트','{bcrypt}$2a$10$w41NwYclLHcx49yTl3YnYuXe8loRfBV19ZwtxJ.YbmNLTtboL6PW2',1,NULL,'PG'),(65,'coby0927@naver.com','팟칭','{bcrypt}$2a$10$GqyoUz4If2qTynAIJ5a5tuJYKNxQUcBSYUjvhXKHZ0197wEzwyY5.',1,NULL,'PG'),(66,'sciplusa@naver.com','영상최종테스트','{bcrypt}$2a$10$aD2t4OcMx5TZ1Ya2qswTh.26IkuFSVrnlGG9LeS.ZolWOdUYhUKNy',1,NULL,'PG'),(67,'10100sam@gmail.com','김상재씨','{bcrypt}$2a$10$RHC0h921Ytg6tX47S8C3geRKQ4sml8p2SYQPTTZ6PuY6g./ul.rfq',0,NULL,'USER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  3:25:49
